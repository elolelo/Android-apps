package com.lelo.currencies;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    Map<String, String> questions = new HashMap<String,String>();

    // instance variables and object references:
    int questionNo = 1;
    TextView outcome;
    TextView question;
    TextView answer1;
    TextView answer2;
    TextView answer3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // this is where the location of views starts
        question = findViewById(R.id.question);
        answer1 = findViewById(R.id.Answer1);
        answer2 = findViewById(R.id.Answer2);
        answer3 = findViewById(R.id.Answer3);
        outcome = findViewById(R.id.Outcome);

        // this is where the questions start
        questions.put("Question1", "What is Afghanistan's main currency?");
        questions.put("Right1", "Afghan Afghani");
        questions.put("WrongA1", "Afghan Dollar");
        questions.put("WrongB1", "Afghan Rands");

        questions.put("Question2", "What color is Albania's main currency?");
        questions.put("Right2", "Albanian Lek");
        questions.put("WrongA2", "Albanian Coins");
        questions.put("WrongB2", "Albanian Dollar");

        questions.put("Question3", "What is main Andorra's currency?");
        questions.put("Right3", "Euro ");
        questions.put("WrongA3", " Rands");
        questions.put("WrongB3", "Andorra Dollars");

        questions.put("Question4", "What is Angola's main currency?");
        questions.put("Right4", " Angolan Kwanza");
        questions.put("WrongA4", "Angolan Euro ");
        questions.put("WrongB4", " Angolan Dollar");

        questions.put("Question5", "What is Antigua and Barbuda's main currency?");
        questions.put("Right5", " East Caribbean Dollar ");
        questions.put("WrongA5", "Barbudan Dollar ");
        questions.put("WrongB5", " Antiguan Rand ");

        questions.put("Question6", "What is Argentina's main currency?");
        questions.put("Right6", " Argentine Peso");
        questions.put("WrongA6", " Argentinan Dollar");
        questions.put("WrongB6", " Argentina Euro ");

        questions.put("Question7", "What is Armenia's main currency?");
        questions.put("Right7", " Armenian Dram");
        questions.put("WrongA7", "Armenian Dollar ");
        questions.put("WrongB7", " Armenia Euro");

        questions.put("Question8", "What is Australia's main currency?");
        questions.put("Right8", " Australian Dollar");
        questions.put("WrongA8", " Australia Euro");
        questions.put("WrongB8", " Australian Rand");

        questions.put("Question9", "What is Austria's  main currency?");
        questions.put("Right9", " Euro");
        questions.put("WrongA9", " Austria Euro");
        questions.put("WrongB9", " Austria Dollar");

        questions.put("Question10", "What is  Azerbaijan's main currency?");
        questions.put("Right10", " Azerbaijani manat ");
        questions.put("WrongA10", " Azerbaijani Dollar");
        questions.put("WrongB10", " Euro");

        //end of the first 10

        questions.put("Question11", "What is Bahamas's main currency?");
        questions.put("Right11", " Bahamian Dollar ");
        questions.put("WrongA11", "Bahamian Euro ");
        questions.put("WrongB11", " Bahamian Rands ");

        questions.put("Question12", "What is Bahrain's main currency?");
        questions.put("Right12", " Bahrain  dinar");
        questions.put("WrongA12", " Bahrain euro ");
        questions.put("WrongB12", " Bahrain dollar ");

        questions.put("Question13", "What is Bangladesh's main currency?");
        questions.put("Right13", " Bangladeshi take");
        questions.put("WrongA13", "  Bangladesh dinar");
        questions.put("WrongB13", " Bangladesh dollar");

        questions.put("Question14", "What is  Barbados's main currency?");
        questions.put("Right14", "  Barbadian dollar");
        questions.put("WrongA14", " Barbadian rupee ");
        questions.put("WrongB14", " Barbados dinar");

        questions.put("Question15", "What is Belarus's main currency?");
        questions.put("Right15", "Belarusian ruble ");
        questions.put("WrongA15", "Belarusian rand ");
        questions.put("WrongB15", " Belarusian dollar");

        questions.put("Question16", "What is Belgium's main currency?");
        questions.put("Right16", "Euro ");
        questions.put("WrongA16", " Belgian dollar");
        questions.put("WrongB16", " Belgiuan rand");

        questions.put("Question17", "What is Belize's main currency?");
        questions.put("Right17", " Belize dollar");
        questions.put("WrongA17", "Belize euro ");
        questions.put("WrongB17", " Belize rand");

        questions.put("Question18", "What is Benin's main currency?");
        questions.put("Right18", " West African CFA Franc ");
        questions.put("WrongA18", " Benin dollar ");
        questions.put("WrongB18", " Benin Euro ");

        questions.put("Question19", "What is Bhutan's main currency?");
        questions.put("Right19", " Bhutanese ngultrum");
        questions.put("WrongA19", " Bhutanese euro");
        questions.put("WrongB19", "Bhutanian dollar ");

        questions.put("Question20", "What is Bolivia's main currency?");
        questions.put("Right20", " Bolivian boliviano");
        questions.put("WrongA20", " Bolivian euro ");
        questions.put("WrongB20", " Bolivian rand ");

        // end of the second 10


        questions.put("Question21", "What is Bosnia and Herzegovina's main currency?");
        questions.put("Right21", " Bosnia and Herzegovina convertible mark ");
        questions.put("WrongA21", "Bosnia and Herzegovina dollar ");
        questions.put("WrongB21", " Bosnia and Herzegovina euro");

        questions.put("Question22", "What is Botswana's main currency?");
        questions.put("Right22", " Botswana Pula");
        questions.put("WrongA22", " Botswana loti ");
        questions.put("WrongB22", " Botswana rands");

        questions.put("Question23", "What is Brazil's main currency?");
        questions.put("Right23", " Brazilian real ");
        questions.put("WrongA23", " Brazilian euro");
        questions.put("WrongB23", " Brazilain dollar");

        questions.put("Question24", "What is Brunei's main currency?");
        questions.put("Right24", " Brunei's dollar");
        questions.put("WrongA24", " Brunei euro");
        questions.put("WrongB24", " Brunei rand");

        questions.put("Question25", "What is Bulgaria's main currency?");
        questions.put("Right25", "Bulgarian lev ");
        questions.put("WrongA25", "Bulgaria dollar ");
        questions.put("WrongB25", " Bulgaria euro");

        questions.put("Question26", "What is Burkina Faso's main currency?");
        questions.put("Right26", "West African CFA Franc ");
        questions.put("WrongA26", " Burkina Faso's dollar");
        questions.put("WrongB26", "Burkina dinar ");

        questions.put("Question27", "What is Burundi's main currency?");
        questions.put("Right27", " Burundian Franc");
        questions.put("WrongA27", "Euro ");
        questions.put("WrongB27", " Burundian Dollar");

        questions.put("Question28", "What is Cambodia main currency?");
        questions.put("Right28", " Cambodian riel");
        questions.put("WrongA28", "Cambodian rands ");
        questions.put("WrongB28", " Cambodian dollar");

        questions.put("Question29", "What is Cameroon's main currency?");
        questions.put("Right29", "Central African CFA Franc ");
        questions.put("WrongA29", "Cameroon dollar ");
        questions.put("WrongB29", " West African CFA Franc");

        questions.put("Question30", "What is Canada's main currency?");
        questions.put("Right30", " Canadian dollar");
        questions.put("WrongA30", " Canadina euro");
        questions.put("WrongB30", " Canadian rand");

        // end of the 3rd 10


        questions.put("Question31", "What is Cape Verde's main currency?");
        questions.put("Right31", "Cape Verde Escudo ");
        questions.put("WrongA31", " Cape Verde Franc");
        questions.put("WrongB31", " Cape Verde Dollar");

        questions.put("Question32", "What is Central African Republic's main currency?");
        questions.put("Right32", "Central African CFA Franc ");
        questions.put("WrongA32", " West African CFA Franc ");
        questions.put("WrongB32", " CFA Dollar");

        questions.put("Question33", "What is  Chad's main currency?");
        questions.put("Right33", " Central African CFA Franc ");
        questions.put("WrongA33", " Chadian Dollan");
        questions.put("WrongB33", " Chadian Euro");

        questions.put("Question34", "What is Chile's main currency?");
        questions.put("Right34", " Chilean Peso");
        questions.put("WrongA34", " Chilean Dollar");
        questions.put("WrongB34", " Chilean Euro");

        questions.put("Question35", "What is China's main currency?");
        questions.put("Right35", " Chinese yuan");
        questions.put("WrongA35", " Chinese Dollar");
        questions.put("WrongB35", " Chinese Rand");

        questions.put("Question36", "What is Colombia's main currency?");
        questions.put("Right36", " Colombian Peso");
        questions.put("WrongA36", " Colombian Dollar");
        questions.put("WrongB36", "Colombian Euro ");

        questions.put("Question37", "What is Comoros main currency?");
        questions.put("Right37", " Comorian franc");
        questions.put("WrongA37", "Comorian Rand ");
        questions.put("WrongB37", " Comorian Dollar");

        questions.put("Question38", "What is Costa Rico's main currency?");
        questions.put("Right38", "Costa Rican colón ");
        questions.put("WrongA38", " Costa Rican Dollar");
        questions.put("WrongB38", " Costa Rican Euro ");

        questions.put("Question39", "What is Crotia's main currency?");
        questions.put("Right39", " Croatian kuna");
        questions.put("WrongA39", " Croatian Franc");
        questions.put("WrongB39", "Croatian Dollar ");

        questions.put("Question40", "What is Cuba's main currency?");
        questions.put("Right40", "Cuban peso ");
        questions.put("WrongA40", "Cuban dollar ");
        questions.put("WrongB40", "Cuban franc ");

        // end of the 4th 10

        questions.put("Question41", "What is Cyprus's main currency?");
        questions.put("Right41", " Euro");
        questions.put("WrongA41", " Cyprian Dollar");
        questions.put("WrongB41", " Cyprian Peso");

        questions.put("Question42", "What is Czech Republic's main currency?");
        questions.put("Right42", " Czech Koruna");
        questions.put("WrongA42", "Euro ");
        questions.put("WrongB42", " Czech Dollar");

        questions.put("Question43", "What is Democratic Republic of Congo's main currency?");
        questions.put("Right43", " Congolese Franc");
        questions.put("WrongA43", " Congolese Dollar ");
        questions.put("WrongB43", " Congolese Euro");

        questions.put("Question44", "What is Denmark's main currency?");
        questions.put("Right44", " Danish Krone");
        questions.put("WrongA44", "Danish dollar ");
        questions.put("WrongB44", "Danish Rands ");

        questions.put("Question45", "What is Djibouti's main currency?");
        questions.put("Right45", " Djiboutian Franc");
        questions.put("WrongA45", "Djiboutian Dollar ");
        questions.put("WrongB45", " Djiboutian Euro ");

        questions.put("Question46", "What is Dominica's main currency?");
        questions.put("Right46", " East Carribean Dollar ");
        questions.put("WrongA46", " Dominican Dollar");
        questions.put("WrongB46", " Dominican Peso");

        questions.put("Question47", "What is Dominican Republic's main currency?");
        questions.put("Right47", " Dominican Peso");
        questions.put("WrongA47", "Dominican Dollar ");
        questions.put("WrongB47", " Dominican Rand");

        questions.put("Question48", "What is East Timor's main currency?");
        questions.put("Right48", " United States Dollar");
        questions.put("WrongA48", " East Timor's Euro ");
        questions.put("WrongB48", " East Timorian Franc");

        questions.put("Question49", "What is Ecuador's main currency?");
        questions.put("Right49", " United States Dollar");
        questions.put("WrongA49", " Ecuador's Dollar");
        questions.put("WrongB49", " Ecuador's Euro");

        questions.put("Question50", "What isEgypt's main currency?");
        questions.put("Right50", " Egyptian Pound ");
        questions.put("WrongA50", " Egyptian Dollar");
        questions.put("WrongB50", " Egyptian Euro");

        // end of the 5th 10

        questions.put("Question51", "What is El Salvador's main currency?");
        questions.put("Right51", "United States Dollar ");
        questions.put("WrongA51", "El Salvador Pound ");
        questions.put("WrongB51", " El Salvador Euro");

        questions.put("Question52", "What is Equatorial Guinea's main currency?");
        questions.put("Right52", " Central African Franc");
        questions.put("WrongA52", " Central African Dollar");
        questions.put("WrongB52", "  Equatorial Guinean Pound");

        questions.put("Question53", "What is Eritrea's main currency?");
        questions.put("Right53", "Eritrean Nakfa ");
        questions.put("WrongA53", " Eritrean Pound");
        questions.put("WrongB53", " Eritrea Dollar");

        questions.put("Question54", "What is Estonia's main currency?");
        questions.put("Right54", " Euro");
        questions.put("WrongA54", "Estonian Dollar ");
        questions.put("WrongB54", " Estonian Rand");

        questions.put("Question55", "What is Ethiopia's main currency?");
        questions.put("Right55", "Ethiopian Birr ");
        questions.put("WrongA55", "Ethiopian Pound ");
        questions.put("WrongB55", "Ethiopian Dollar ");

        questions.put("Question56", "What is Fiji's main currency?");
        questions.put("Right56", " Fijian Dollar ");
        questions.put("WrongA56", " Fijian Euro");
        questions.put("WrongB56", " Fijian Pound");

        questions.put("Question57", "What is Finland's main currency?");
        questions.put("Right57", " Euro");
        questions.put("WrongA57", "United States Dollar ");
        questions.put("WrongB57", " Finland Pound ");

        questions.put("Question58", "What is France's main currency?");
        questions.put("Right58", " Euro");
        questions.put("WrongA58", " Franc");
        questions.put("WrongB58", " United States Dollar");

        questions.put("Question59", "What is Gabon's main currency?");
        questions.put("Right59", "Central African CFA Franc ");
        questions.put("WrongA59", " Gabon's Dollar ");
        questions.put("WrongB59", " Gabon Pound");

        questions.put("Question60", "What is Gambia's main currency?");
        questions.put("Right60", "Gambain Dalasi ");
        questions.put("WrongA60", "Gambian Pound ");
        questions.put("WrongB60", "Gambain Dollar ");

        // end of the 6th 10


        questions.put("Question61", "What is Georgia's main currency?");
        questions.put("Right61", " Georgian Lari ");
        questions.put("WrongA61", " Euro");
        questions.put("WrongB61", " Goergian Pound");

        questions.put("Question62", "What is Germany's main currency?");
        questions.put("Right62", " Euro");
        questions.put("WrongA62", " German Dollar");
        questions.put("WrongB62", "  German  Pound");

        questions.put("Question63", "What is Ghana's main currency?");
        questions.put("Right63", "  Ghanaian Cedi");
        questions.put("WrongA63", " Ghanaian Dollar ");
        questions.put("WrongB63", " Ghanaian Pound");

        questions.put("Question64", "What is Greece's main currency?");
        questions.put("Right64", " Euro");
        questions.put("WrongA64", "Greece Dollar ");
        questions.put("WrongB64", "Greece Pound ");

        questions.put("Question65", "What is Grenada's main currency?");
        questions.put("Right65", " East Carribbean Dollar ");
        questions.put("WrongA65", " Grenadaian Pound ");
        questions.put("WrongB65", " Grenadaian Franc");

        questions.put("Question66", "What is  Guatemala's main currency?");
        questions.put("Right66", " Guatemalan quetzal");
        questions.put("WrongA66", "Guatemalan's Dollar ");
        questions.put("WrongB66", " Guatemala's Pound");

        questions.put("Question67", "What is Guinea's main currency?");
        questions.put("Right67", "Guinean Franc ");
        questions.put("WrongA67", " Guinean Dollar ");
        questions.put("WrongB67", " Guinean Euro ");

        questions.put("Question68", "What is Guinea-Bissau's main currency?");
        questions.put("Right68", " West African  CFA Franc ");
        questions.put("WrongA68", "Guinea-Bissau Franc ");
        questions.put("WrongB68", " Guinea-Bissau Dollar");

        questions.put("Question69", "What is Guyana's main currency?");
        questions.put("Right69", "Guyanese Dollar ");
        questions.put("WrongA69", "Guyana Pound ");
        questions.put("WrongB69", " Guyana Franc");

        questions.put("Question70", "What is Haiti's main currency?");
        questions.put("Right70", " Haitian gourde");
        questions.put("WrongA70", " Haitian Pound ");
        questions.put("WrongB70", " Haitian Dollar");

        // end of the 7th 10

        questions.put("Question71", "What is Honduras's main currency?");
        questions.put("Right71", " Honduras lempira");
        questions.put("WrongA71", " Honduran Pound");
        questions.put("WrongB71", " Honduran Dollar");

        questions.put("Question72", "What is Hungary's main currency?");
        questions.put("Right72", " Hungarian Forint");
        questions.put("WrongA72", "Hundarian Pound ");
        questions.put("WrongB72", " Hundarian Euro");

        questions.put("Question73", "What is Iceland's main currency?");
        questions.put("Right73", " Icelandic króna");
        questions.put("WrongA73", " Iceland Pound");
        questions.put("WrongB73", " Iceland Euro");

        questions.put("Question74", "What is India's main currency?");
        questions.put("Right74", " Indian Rupee");
        questions.put("WrongA74", "Indian  Pound");
        questions.put("WrongB74", " Indian Dollar");

        questions.put("Question75", "What is Indonesia's main currency?");
        questions.put("Right75", " Indonesian rupiah");
        questions.put("WrongA75", " Indonesian Dollar");
        questions.put("WrongB75", " Indonesian Pound");

        questions.put("Question76", "What is Iran's main currency?");
        questions.put("Right76", "Iranian rial ");
        questions.put("WrongA76", " Rupee");
        questions.put("WrongB76", " Iranian pound");


        /* took a break from here --
        questions.put("Question77", "What is main currency?");
        questions.put("Right77", " ");
        questions.put("WrongA77", " ");
        questions.put("WrongB77", " ");

        questions.put("Question78", "What is main currency?");
        questions.put("Right78", " ");
        questions.put("WrongA78", " ");
        questions.put("WrongB78", " ");

        questions.put("Question79", "What is main currency?");
        questions.put("Right79", " ");
        questions.put("WrongA79", " ");
        questions.put("WrongB79", " ");

        questions.put("Question80", "What is main currency?");
        questions.put("Right80", " ");
        questions.put("WrongA80", " ");
        questions.put("WrongB80", " ");

        // end of the 8th 10

        questions.put("Question81", "What is main currency?");
        questions.put("Right81", " ");
        questions.put("WrongA81", " ");
        questions.put("WrongB81", " ");

        questions.put("Question82", "What is main currency?");
        questions.put("Right82", " ");
        questions.put("WrongA82", " ");
        questions.put("WrongB82", " ");

        questions.put("Question83", "What is main currency?");
        questions.put("Right83", " ");
        questions.put("WrongA83", " ");
        questions.put("WrongB83", " ");

        questions.put("Question84", "What is main currency?");
        questions.put("Right84", " ");
        questions.put("WrongA84", " ");
        questions.put("WrongB84", " ");

        questions.put("Question85", "What is main currency?");
        questions.put("Right85", " ");
        questions.put("WrongA85", " ");
        questions.put("WrongB85", " ");

        questions.put("Question86", "What is main currency?");
        questions.put("Right86", " ");
        questions.put("WrongA86", " ");
        questions.put("WrongB86", " ");

        questions.put("Question87", "What is main currency?");
        questions.put("Right87", " ");
        questions.put("WrongA87", " ");
        questions.put("WrongB87", " ");

        questions.put("Question88", "What is main currency?");
        questions.put("Right88", " ");
        questions.put("WrongA88", " ");
        questions.put("WrongB88", " ");

        questions.put("Question89", "What is main currency?");
        questions.put("Right89", " ");
        questions.put("WrongA89", " ");
        questions.put("WrongB89", " ");

        questions.put("Question90", "What is main currency?");
        questions.put("Right90", " ");
        questions.put("WrongA90", " ");
        questions.put("WrongB90", " ");

        // end of the 9th 10

        questions.put("Question91", "What is main currency?");
        questions.put("Right91", " ");
        questions.put("WrongA91", " ");
        questions.put("WrongB91", " ");

        questions.put("Question92", "What is main currency?");
        questions.put("Right92", " ");
        questions.put("WrongA92", " ");
        questions.put("WrongB92", " ");

        questions.put("Question93", "What is main currency?");
        questions.put("Right93", " ");
        questions.put("WrongA93", " ");
        questions.put("WrongB93", " ");

        questions.put("Question94", "What is main currency?");
        questions.put("Right94", " ");
        questions.put("WrongA94", " ");
        questions.put("WrongB94", " ");

        questions.put("Question95", "What is main currency?");
        questions.put("Right95", " ");
        questions.put("WrongA95", " ");
        questions.put("WrongB95", " ");

        questions.put("Question96", "What is main currency?");
        questions.put("Right96", " ");
        questions.put("WrongA96", " ");
        questions.put("WrongB96", " ");

        questions.put("Question97", "What is main currency?");
        questions.put("Right97", " ");
        questions.put("WrongA97", " ");
        questions.put("WrongB97", " ");

        questions.put("Question98", "What is main currency?");
        questions.put("Right98", " ");
        questions.put("WrongA98", " ");
        questions.put("WrongB98", " ");

        questions.put("Question99", "What is main currency?");
        questions.put("Right99", " ");
        questions.put("WrongA99", " ");
        questions.put("WrongB99", " ");

        questions.put("Question100", "What is main currency?");
        questions.put("Right100", " ");
        questions.put("WrongA100", " ");
        questions.put("WrongB100", " ");

         end of the 10th 10

        questions.put("Question101", "What is main currency?");
        questions.put("Right101", " ");
        questions.put("WrongA101", " ");
        questions.put("WrongB101", " ");

        questions.put("Question102", "What is main currency?");
        questions.put("Right102", " ");
        questions.put("WrongA102", " ");
        questions.put("WrongB102", " ");

        questions.put("Question103", "What is main currency?");
        questions.put("Right103", " ");
        questions.put("WrongA103", " ");
        questions.put("WrongB103", " ");

        questions.put("Question104", "What is main currency?");
        questions.put("Right104", " ");
        questions.put("WrongA104", " ");
        questions.put("WrongB104", " ");

        questions.put("Question105", "What is main currency?");
        questions.put("Right105", " ");
        questions.put("WrongA105", " ");
        questions.put("WrongB105", " ");

        questions.put("Question106", "What is main currency?");
        questions.put("Right106", " ");
        questions.put("WrongA106", " ");
        questions.put("WrongB106", " ");

        questions.put("Question107", "What is main currency?");
        questions.put("Right107", " ");
        questions.put("WrongA107", " ");
        questions.put("WrongB107", " ");

        questions.put("Question108", "What is main currency?");
        questions.put("Right108", " ");
        questions.put("WrongA108", " ");
        questions.put("WrongB108", " ");

        questions.put("Question109", "What is main currency?");
        questions.put("Right109", " ");
        questions.put("WrongA109", " ");
        questions.put("WrongB109", " ");

        questions.put("Question110", "What is main currency?");
        questions.put("Right110", " ");
        questions.put("WrongA110", " ");
        questions.put("WrongB110", " ");

        //end of 11th 10

        questions.put("Question111", "What is main currency?");
        questions.put("Right111", " ");
        questions.put("WrongA111", " ");
        questions.put("WrongB111", " ");

        questions.put("Question112", "What is main currency?");
        questions.put("Right112", " ");
        questions.put("WrongA112", " ");
        questions.put("WrongB112", " ");

        questions.put("Question113", "What is main currency?");
        questions.put("Right113", " ");
        questions.put("WrongA113", " ");
        questions.put("WrongB113", " ");

        questions.put("Question114", "What is main currency?");
        questions.put("Right114", " ");
        questions.put("WrongA114", " ");
        questions.put("WrongB114", " ");

        questions.put("Question115", "What is main currency?");
        questions.put("Right115", " ");
        questions.put("WrongA115", " ");
        questions.put("WrongB115", " ");

        questions.put("Question116", "What is main currency?");
        questions.put("Right116", " ");
        questions.put("WrongA116", " ");
        questions.put("WrongB116", " ");

        questions.put("Question117", "What is main currency?");
        questions.put("Right117", " ");
        questions.put("WrongA117", " ");
        questions.put("WrongB117", " ");

        questions.put("Question118", "What is main currency?");
        questions.put("Right118", " ");
        questions.put("WrongA118", " ");
        questions.put("WrongB118", " ");

        questions.put("Question119", "What is main currency?");
        questions.put("Right119", " ");
        questions.put("WrongA119", " ");
        questions.put("WrongB119", " ");

        questions.put("Question120", "What is main currency?");
        questions.put("Right120", " ");
        questions.put("WrongA120", " ");
        questions.put("WrongB120", " ");

        // end  of 12th 10

        questions.put("Question121", "What is main currency?");
        questions.put("Right121", " ");
        questions.put("WrongA121", " ");
        questions.put("WrongB121", " ");

        questions.put("Question122", "What is main currency?");
        questions.put("Right122", " ");
        questions.put("WrongA122", " ");
        questions.put("WrongB122", " ");

        questions.put("Question123", "What is main currency?");
        questions.put("Right123", " ");
        questions.put("WrongA123", " ");
        questions.put("WrongB123", " ");

        questions.put("Question124", "What is main currency?");
        questions.put("Right124", " ");
        questions.put("WrongA124", " ");
        questions.put("WrongB124", " ");

        questions.put("Question125", "What is main currency?");
        questions.put("Right125", " ");
        questions.put("WrongA125", " ");
        questions.put("WrongB125", " ");

        questions.put("Question126", "What is main currency?");
        questions.put("Right126", " ");
        questions.put("WrongA126", " ");
        questions.put("WrongB126", " ");

        questions.put("Question127", "What is main currency?");
        questions.put("Right127", " ");
        questions.put("WrongA127", " ");
        questions.put("WrongB127", " ");

        questions.put("Question128", "What is main currency?");
        questions.put("Right128", " ");
        questions.put("WrongA128", " ");
        questions.put("WrongB128", " ");

        questions.put("Question129", "What is main currency?");
        questions.put("Right129", " ");
        questions.put("WrongA129", " ");
        questions.put("WrongB129", " ");

        questions.put("Question130", "What is main currency?");
        questions.put("Right130", " ");
        questions.put("WrongA130", " ");
        questions.put("WrongB130", " ");

        // end of 13th 10

        questions.put("Question131", "What is main currency?");
        questions.put("Right131", " ");
        questions.put("WrongA131", " ");
        questions.put("WrongB131", " ");

        questions.put("Question132", "What is main currency?");
        questions.put("Right132", " ");
        questions.put("WrongA132", " ");
        questions.put("WrongB132", " ");

        questions.put("Question133", "What is main currency?");
        questions.put("Right133", " ");
        questions.put("WrongA133", " ");
        questions.put("WrongB133", " ");

        questions.put("Question134", "What is main currency?");
        questions.put("Right134", " ");
        questions.put("WrongA134", " ");
        questions.put("WrongB134", " ");

        questions.put("Question135", "What is main currency?");
        questions.put("Right135", " ");
        questions.put("WrongA135", " ");
        questions.put("WrongB135", " ");

        questions.put("Question136", "What is main currency?");
        questions.put("Right136", " ");
        questions.put("WrongA136", " ");
        questions.put("WrongB136", " ");

        questions.put("Question137", "What is main currency?");
        questions.put("Right137", " ");
        questions.put("WrongA137", " ");
        questions.put("WrongB137", " ");

        questions.put("Question138", "What is main currency?");
        questions.put("Right138", " ");
        questions.put("WrongA138", " ");
        questions.put("WrongB138", " ");

        questions.put("Question139", "What is main currency?");
        questions.put("Right139", " ");
        questions.put("WrongA139", " ");
        questions.put("WrongB139", " ");

        questions.put("Question140", "What is main currency?");
        questions.put("Right140", " ");
        questions.put("WrongA140", " ");
        questions.put("WrongB140", " ");

        //end of 14th 10

        questions.put("Question141", "What is main currency?");
        questions.put("Right141", " ");
        questions.put("WrongA141", " ");
        questions.put("WrongB141", " ");

        questions.put("Question142", "What is main currency?");
        questions.put("Right142", " ");
        questions.put("WrongA142", " ");
        questions.put("WrongB142", " ");

        questions.put("Question143", "What is main currency?");
        questions.put("Right143", " ");
        questions.put("WrongA143", " ");
        questions.put("WrongB143", " ");

        questions.put("Question144", "What is main currency?");
        questions.put("Right144", " ");
        questions.put("WrongA144", " ");
        questions.put("WrongB144", " ");

        questions.put("Question145", "What is main currency?");
        questions.put("Right145", " ");
        questions.put("WrongA145", " ");
        questions.put("WrongB145", " ");

        questions.put("Question146", "What is main currency?");
        questions.put("Right146", " ");
        questions.put("WrongA146", " ");
        questions.put("WrongB146", " ");

        questions.put("Question147", "What is main currency?");
        questions.put("Right147", " ");
        questions.put("WrongA147", " ");
        questions.put("WrongB147", " ");

        questions.put("Question148", "What is main currency?");
        questions.put("Right148", " ");
        questions.put("WrongA148", " ");
        questions.put("WrongB148", " ");

        questions.put("Question149", "What is main currency?");
        questions.put("Right146", " ");
        questions.put("WrongA149", " ");
        questions.put("WrongB149", " ");

        questions.put("Question150", "What is main currency?");
        questions.put("Right150", " ");
        questions.put("WrongA150", " ");
        questions.put("WrongB150", " ");

        // end of 15th 10

        questions.put("Question151", "What is main currency?");
        questions.put("Right151", " ");
        questions.put("WrongA151", " ");
        questions.put("WrongB151", " ");

        questions.put("Question152", "What is main currency?");
        questions.put("Right152", " ");
        questions.put("WrongA152", " ");
        questions.put("WrongB152", " ");

        questions.put("Question153", "What is main currency?");
        questions.put("Right153", " ");
        questions.put("WrongA153", " ");
        questions.put("WrongB153", " ");


        questions.put("Question154", "What is main currency?");
        questions.put("Right154", " ");
        questions.put("WrongA154", " ");
        questions.put("WrongB154", " ");


        questions.put("Question155", "What is main currency?");
        questions.put("Right155", " ");
        questions.put("WrongA155", " ");
        questions.put("WrongB155", " ");

        questions.put("Question156", "What is main currency?");
        questions.put("Right156", " ");
        questions.put("WrongA156", " ");
        questions.put("WrongB156", " ");

        questions.put("Question157", "What is main currency?");
        questions.put("Right157", " ");
        questions.put("WrongA157", " ");
        questions.put("WrongB157", " ");

        questions.put("Question158", "What is main currency?");
        questions.put("Right158", " ");
        questions.put("WrongA158", " ");
        questions.put("WrongB158", " ");

        questions.put("Question159", "What is main currency?");
        questions.put("Right159", " ");
        questions.put("WrongA159", " ");
        questions.put("WrongB159", " ");

        questions.put("Question160", "What is main currency?");
        questions.put("Right160", " ");
        questions.put("WrongA160", " ");
        questions.put("WrongB160", " ");

        //end of 16th 10

        questions.put("Question161", "What is main currency?");
        questions.put("Right161", " ");
        questions.put("WrongA161", " ");
        questions.put("WrongB161", " ");

        questions.put("Question162", "What is main currency?");
        questions.put("Right162", " ");
        questions.put("WrongA162", " ");
        questions.put("WrongB162", " ");

        questions.put("Question164", "What is main currency?");
        questions.put("Right164", " ");
        questions.put("WrongA164", " ");
        questions.put("WrongB164", " ");

        questions.put("Question165", "What is main currency?");
        questions.put("Right165", " ");
        questions.put("WrongA165", " ");
        questions.put("WrongB165", " ");

        questions.put("Question166", "What is main currency?");
        questions.put("Right166", " ");
        questions.put("WrongA166", " ");
        questions.put("WrongB166", " ");

        questions.put("Question167", "What is main currency?");
        questions.put("Right167", " ");
        questions.put("WrongA167", " ");
        questions.put("WrongB167", " ");

        questions.put("Question168", "What is main currency?");
        questions.put("Right168", " ");
        questions.put("WrongA168", " ");
        questions.put("WrongB168", " ");

        questions.put("Question169", "What is main currency?");
        questions.put("Right169", " ");
        questions.put("WrongA169", " ");
        questions.put("WrongB169", " ");

        questions.put("Question170", "What is main currency?");
        questions.put("Right170", " ");
        questions.put("WrongA170", " ");
        questions.put("WrongB170", " ");

        // end of 17th 10
        questions.put("Question171", "What is main currency?");
        questions.put("Right171", " ");
        questions.put("WrongA171", " ");
        questions.put("WrongB171", " ");

        questions.put("Question172", "What is main currency?");
        questions.put("Right172", " ");
        questions.put("WrongA172", " ");
        questions.put("WrongB172", " ");

        questions.put("Question173", "What is main currency?");
        questions.put("Right173", " ");
        questions.put("WrongA173", " ");
        questions.put("WrongB173", " ");

        questions.put("Question174", "What is main currency?");
        questions.put("Right174", " ");
        questions.put("WrongA174", " ");
        questions.put("WrongB174", " ");

        questions.put("Question175", "What is main currency?");
        questions.put("Right175", " ");
        questions.put("WrongA175", " ");
        questions.put("WrongB175", " ");

        questions.put("Question176", "What is main currency?");
        questions.put("Right176", " ");
        questions.put("WrongA176", " ");
        questions.put("WrongB176", " ");

        questions.put("Question177", "What is main currency?");
        questions.put("Right177", " ");
        questions.put("WrongA177", " ");
        questions.put("WrongB177", " ");

        questions.put("Question178", "What is main currency?");
        questions.put("Right178", " ");
        questions.put("WrongA178", " ");
        questions.put("WrongB178", " ");

        questions.put("Question179", "What is main currency?");
        questions.put("Right179", " ");
        questions.put("WrongA179", " ");
        questions.put("WrongB179", " ");

        questions.put("Question180", "What is main currency?");
        questions.put("Right180", " ");
        questions.put("WrongA180", " ");
        questions.put("WrongB180", " ");

        // end of all the questions  */


    }


    public void onAnswer1Click(View v) {
        if (v.getTag() == "Correct") {
            questionNo++;
            if ((questionNo * 4) > questions.size()) {
                outcome.setText("You Win!");
            } else {
                outcome.setText("Well Done!");
                setQuestion();
            }
        } else {
            outcome.setText("Try again!");
        }

    }

    public void onAnswer2Click(View v) {
        if (v.getTag() == "Correct") {
            questionNo++;
            if ((questionNo * 4) > questions.size()) {
                outcome.setText("You Win!");
            } else {
                outcome.setText("Well Done!");
                setQuestion();
            }
        } else {
            outcome.setText("Try again!");
        }

    }

    public void onAnswer3Click(View v) {
        if (v.getTag() == "Correct") {
            questionNo++;
            if ((questionNo * 4) > questions.size()) {
                outcome.setText("You Win!");
            } else {
                outcome.setText("Well Done!");
                setQuestion();
            }
        } else {
            outcome.setText("Try again!");
        }

    }

    // the randomizer
    private void setQuestion() {
        question.setText(questions.get("Question" + questionNo).toString());
        answer1.setText(questions.get("Right" + questionNo).toString());
        answer1.setTag("Correct");
        answer2.setText(questions.get("WrongA" + questionNo).toString());
        answer3.setText(questions.get("WrongB" + questionNo).toString());

        List currentAnswers = new ArrayList(3);
        currentAnswers.add(questions.get("Right" + questionNo).toString());
        currentAnswers.add(questions.get("WrongA" + questionNo).toString());
        currentAnswers.add(questions.get("WrongB" + questionNo).toString());
        Collections.shuffle(currentAnswers);

        question.setText(questions.get("Question" + questionNo).toString());
        answer1.setText(currentAnswers.get(0).toString());
        answer2.setText(currentAnswers.get(1).toString());
        answer3.setText(currentAnswers.get(2).toString());

        if (answer1.getText() == questions.get("Right" + questionNo).toString()) {
            answer1.setTag("Correct");
        } else {
            answer1.setTag("Incorrect");
        }

        if (answer2.getText() == questions.get("Right" + questionNo).toString()) {
            answer2.setTag("Correct");
        } else {
            answer2.setTag("Incorrect");
        }

        if (answer3.getText() == questions.get("Right" + questionNo).toString()) {
            answer3.setTag("Correct");
        } else {
            answer3.setTag("Incorrect");
        }

    }


}
